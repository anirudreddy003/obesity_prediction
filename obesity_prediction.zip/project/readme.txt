open the zip file named project 

step 1 - install requirements.txt file for software and package dependcies
step 2 - open jupyter notebook via anaconda prompt 
step 3 - locate ipnb jupyter file and execute the code 
